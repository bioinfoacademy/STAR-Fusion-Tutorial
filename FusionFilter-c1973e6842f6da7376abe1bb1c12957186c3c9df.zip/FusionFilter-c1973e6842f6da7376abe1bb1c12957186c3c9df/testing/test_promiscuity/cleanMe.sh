#!/bin/bash

rm -f ./fusion_preds.txt.post_promisc_filter.info
rm -f ./fusion_preds.txt.post_promisc_filter.sorted
rm -f ./fusion_preds.txt.post_promisc_filter
