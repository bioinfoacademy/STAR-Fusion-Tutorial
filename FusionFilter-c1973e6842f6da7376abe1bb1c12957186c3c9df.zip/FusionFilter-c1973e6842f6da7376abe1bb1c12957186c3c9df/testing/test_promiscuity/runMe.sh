#!/bin/bash


../../util/promiscuity_filter.pl  --fusion_preds fusion_preds.txt --genome_lib_dir $CTAT_GENOME_LIB --exclude_loci_overlap_check --max_promiscuity 3

