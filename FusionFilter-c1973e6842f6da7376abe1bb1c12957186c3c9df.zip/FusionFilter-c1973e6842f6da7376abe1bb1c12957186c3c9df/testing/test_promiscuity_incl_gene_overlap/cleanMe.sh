#!/bin/bash

rm -f ./star-fusion.fusion_candidates.preliminary.*

